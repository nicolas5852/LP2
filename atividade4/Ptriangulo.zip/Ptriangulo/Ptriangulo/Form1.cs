﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double numA = 0, numB = 0, numC = 0;

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtB.Text, out numB) || numB == 0)
            {
                MessageBox.Show("Valor Invalido!");
                txtB.Focus();
                txtB.Text = "";
                numB = 0;
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtC.Text, out numC) || numC == 0)
            {                
                MessageBox.Show("Valor Invalido!");
                txtC.Focus();
                txtC.Text = "";
                numC = 0;
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if(numA == 0 || numB == 0 || numC == 0)
            {
                MessageBox.Show("Valores não podem ser zero ou nulos");
                return;
            }

            if((Math.Abs(numB - numC) < numA && numA < numB + numC) ||
                (Math.Abs(numA - numC) < numB && numB < numA+numC) ||
                (Math.Abs(numA - numB) < numC && numC < numA+numB)
                )
            {
                string result = "Triangulo ";
                if(numA == numB && numA == numC && numC == numB)
                {
                    result += "equilatero!";
                }
                else if(numA == numB || numA == numC || numB == numC)
                {
                    result += "isóceles!";
                }
                else
                {
                    result += "escaleno!";
                }

                MessageBox.Show(result);
            }
            else
            {
                MessageBox.Show("Não é triangulo!");
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtA.Text, out numA) || numA == 0)
            {
                MessageBox.Show("Valor Invalido!");
                txtA.Focus();
                txtA.Text = "";
                numA = 0;
            }
        }
    }
}
