﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        double raio;
        double altura;
        double volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void Calcular()
        {
            if (txtAltura.Text != "" & txtRaio.Text != "")
                txtVolume.Text = (Math.PI * Convert.ToDouble(txtRaio.Text) * Convert.ToDouble(txtAltura.Text)).ToString();
            else
                txtVolume.Text = "0";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtVolume.Text = "0";
            
        }

        private void txtRaio_TextChanged(object sender, EventArgs e)
        {

            if(!Double.TryParse(txtRaio.Text, out raio))
            {
                if (!(txtRaio.Text == ""))
                {
                    MessageBox.Show("Numero invalido!");
                    SendKeys.Send("{BACKSPACE}");
                }
                
            }
            else if(raio <= 0)
            {
                MessageBox.Show("Use somente números positivos!");
                raio *= -1;
                txtRaio.Text = raio.ToString();
            }
            Calcular();
        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura))
            {
                if (!(txtAltura.Text == ""))
                {
                    MessageBox.Show("Numero invalido!");
                    SendKeys.Send("{BACKSPACE}");
                }
            }
            else if (altura <= 0)
            {
                MessageBox.Show("Use somente números positivos!");
                altura *= -1;
                txtAltura.Text = altura.ToString();
            }
            Calcular();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtVolume.Text = "0";
            txtRaio.Text = "";
            txtAltura.Text = "";
        }
    }
}
