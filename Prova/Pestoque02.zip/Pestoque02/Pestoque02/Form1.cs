﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pestoque02
{
    public partial class Form1 : Form
    {
        int[,] entradaProdutos = new int[4,4];

        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            lboxResultado.Items.Clear();
            int produto, semana;

            for (produto = 0; produto < 4; produto++) 
            {
                for(semana = 0; semana < 4; semana++)
                {
                    string valor = 
                        Interaction.InputBox($"Informe a entrada do " +
                        $"produto {produto+1} na semana {semana+1}");

                    if(!int.TryParse( valor, out entradaProdutos[produto, semana]))
                    {
                        MessageBox.Show("Valor invalido! " +
                            "Por favor, insira somente numeros sem decimais");
                        semana--;
                    }
                    else
                    {
                        lboxResultado.Items.Add($"Total de entradas do Produto {produto+1} Semana {semana+1}: {entradaProdutos[produto, semana]}");
                    }
                }
                int totalSemana = entradaProdutos[produto ,0] + entradaProdutos[produto, 1]
                    + entradaProdutos[produto, 2] + entradaProdutos[produto, 3];
                lboxResultado.Items.Add("");
                lboxResultado.Items.Add($">>Total de entradas do Produto {produto+1} no mês: {totalSemana}");
                lboxResultado.Items.Add("-------------------------------------------------------------------------");
            }
            int totalGeral = 0;
            for (produto = 0; produto < 4; produto++)
                for (semana = 0; semana < 4; semana++)
                    totalGeral += entradaProdutos[produto, semana];

            lboxResultado.Items.Add($"Total geral de entradas: {totalGeral}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lboxResultado.Items.Clear();
        }
    }
}
