﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        private void CalcularIMC()
        {
            if (altura != 0)
                imc = peso / (altura * altura);
            else
                imc = 0;
            imc = Math.Round(imc, 1);
            txtImc.Text = imc.ToString();
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Numero invalido!");
                txtAltura.Text = "";
                altura = 0;
            }

            CalcularIMC();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if(imc == 0)
                MessageBox.Show("Insira todas as informações!");
            else if(imc < 18.5)
                MessageBox.Show("Resultado: Magreza");
            else if(imc <= 24.9)
                MessageBox.Show("Resultado: Normal");
            else if(imc <= 29.9)
                MessageBox.Show("Resultado: Sobrepeso");
            else if(imc <= 39.9)
                MessageBox.Show("Resultado: Obesidade");
            else
                MessageBox.Show("Resultado: Obesidade Grave!");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            altura = 0;
            txtPeso.Text = "";
            peso = 0;
            txtImc.Text = "";
            imc = 0;
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Numero invalido!");
                txtPeso.Text = "";
                peso = 0;
            }

            CalcularIMC();
        }

        public Form1()
        {
            InitializeComponent();
            txtImc.Text = "0";
        }


    }
}
