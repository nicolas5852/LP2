﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double num1 = 0, num2 = 0, result = 0;
        public Form1()
        {
            InitializeComponent();
            txtResult.Text = "0";
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtNum1.Text, out num1))
            {
                if(txtNum1.Text != "")
                    MessageBox.Show("Valor invalido!");
                else
                    num1 = 0;
                txtNum1.Text = "";
            }
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out num2))
            {
                if (txtNum2.Text != "")
                    MessageBox.Show("Valor invalido!");

                num2 = 0;
                txtNum2.Text = "";
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            result = num1 * num2;
            txtResult.Text = result.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (num2 != 0)
            {
                result = num1 / num2;
                txtResult.Text = result.ToString();
            }
            else
            {
                result = 0;
                txtResult.Text = "NaN";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum2.Text = "";
            txtResult.Text = "0";
            num1 = 0;
            num2 = 0;
            result = 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            result = num1 - num2;
            txtResult.Text = result.ToString();
        }


        private void btnAd_Click(object sender, EventArgs e)
        {
            result = num1 + num2;
            txtResult.Text = result.ToString();
        }
    }
}
