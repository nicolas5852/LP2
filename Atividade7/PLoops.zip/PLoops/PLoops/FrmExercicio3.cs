﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void btnChecar_Click(object sender, EventArgs e)
        {
            string text = txtFrase.Text.ToUpper();
            text = text.Replace(" ", "");

            string reverseText = "";

            for(int i = 0;i <= text.Length - 1;i++)
            {
                reverseText += text[text.Length - 1 - i];
            }

            if(reverseText == text)
            {
                MessageBox.Show(text + " é um palíndromo");
            }
            else
            {
                MessageBox.Show(text + " Não é um palindromo");
            }
        }
    }
}
