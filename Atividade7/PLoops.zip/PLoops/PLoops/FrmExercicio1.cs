﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class BtnPares : Form
    {
        public BtnPares()
        {
            InitializeComponent();
        }

        private void BtnEspaço_Click(object sender, EventArgs e)
        {
            string frase = TxtFrase.Text;
            int espacos = 0;

            for(int i = 0; i < frase.Length; i++)
            {
                if(frase[i] == ' ')
                    espacos++;
            }

            MessageBox.Show("Há " + espacos + " espaços na frase!");
        }

        private void BtnLetraR_Click(object sender, EventArgs e)
        {
            string frase = TxtFrase.Text.ToLower();
            int letrasR = 0;

            foreach(char letras in frase)
            {
                if (letras == 'r')
                    letrasR++;
            }

            MessageBox.Show("Tem " + letrasR + " letras R na frase");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string frase = TxtFrase.Text.ToLower();
            if(frase != "")
            {
                char letra = frase[0];
                int i = 1;
                int pares = 0;

                while (i < frase.Length)
                {
                    if (frase[i] == letra)
                        pares++;
                    else
                        letra = frase[i];
                    i++;
                }

                MessageBox.Show("Tem " + pares + " pares de letras na frase");
            }
            else
            {
                MessageBox.Show("Tem 0 pares de letras na frase");
            }
        }
    }
}
