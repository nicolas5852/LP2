﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            int producao, matricula;
            double salario, gratificacao, b = 0, c = 0, d = 0, salarioBruto;


            if(!int.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Valor de producao invalido!");
                return;
            }
            if (!int.TryParse(txtMatricula.Text, out matricula))
            {
                MessageBox.Show("Valor de matricula invalido!");
                return;
            }
            if (!double.TryParse(txtSalario.Text, out salario))
            {
                MessageBox.Show("Valor de Salario invalido!");
                return;
            }
            if (!double.TryParse(txtGratificacao.Text, out gratificacao))
            {
                MessageBox.Show("Valor de gratificacao invalido!");
                return;
            }
            if(nome == "")
            {
                MessageBox.Show("Nome invalido");
                return;
            }

            if (producao >= 150)
            {
                b = 1;
                c = 1;
                d = 1;
            }
            else if (producao >=120)
            {
                b = 1;
                c = 1;
            }else if(producao >= 100)
            {
                b = 1;
            }

            salarioBruto = salario + salario * (0.05 * b + 0.1 * c + 0.1 * d) + gratificacao;

            if(salarioBruto > 7000 && producao < 150)
            {
                salarioBruto = 7000;
            }

            MessageBox.Show("Nome: " + nome + "\n" +
                "Matricula: " + matricula + "\n" +
                "Salario Bruto: R$" + salarioBruto);
        }
    }
}
