﻿namespace PLoops
{
    partial class BtnPares
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtFrase = new System.Windows.Forms.RichTextBox();
            this.BtnEspaço = new System.Windows.Forms.Button();
            this.BtnLetraR = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TxtFrase
            // 
            this.TxtFrase.Location = new System.Drawing.Point(205, 146);
            this.TxtFrase.MaxLength = 100;
            this.TxtFrase.Name = "TxtFrase";
            this.TxtFrase.Size = new System.Drawing.Size(367, 96);
            this.TxtFrase.TabIndex = 0;
            this.TxtFrase.Text = "";
            // 
            // BtnEspaço
            // 
            this.BtnEspaço.Location = new System.Drawing.Point(205, 320);
            this.BtnEspaço.Name = "BtnEspaço";
            this.BtnEspaço.Size = new System.Drawing.Size(111, 67);
            this.BtnEspaço.TabIndex = 1;
            this.BtnEspaço.Text = "Espaços";
            this.BtnEspaço.UseVisualStyleBackColor = true;
            this.BtnEspaço.Click += new System.EventHandler(this.BtnEspaço_Click);
            // 
            // BtnLetraR
            // 
            this.BtnLetraR.Location = new System.Drawing.Point(333, 320);
            this.BtnLetraR.Name = "BtnLetraR";
            this.BtnLetraR.Size = new System.Drawing.Size(111, 67);
            this.BtnLetraR.TabIndex = 2;
            this.BtnLetraR.Text = "Letras R";
            this.BtnLetraR.UseVisualStyleBackColor = true;
            this.BtnLetraR.Click += new System.EventHandler(this.BtnLetraR_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(461, 320);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(111, 67);
            this.button3.TabIndex = 3;
            this.button3.Text = "Par de letras";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // BtnPares
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.BtnLetraR);
            this.Controls.Add(this.BtnEspaço);
            this.Controls.Add(this.TxtFrase);
            this.Name = "BtnPares";
            this.Text = "FrmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox TxtFrase;
        private System.Windows.Forms.Button BtnEspaço;
        private System.Windows.Forms.Button BtnLetraR;
        private System.Windows.Forms.Button button3;
    }
}