﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<BtnPares>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio1"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                BtnPares obj1 = new BtnPares(); // crio o objeto do novo formulario
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio2>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio2"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                FrmExercicio2 obj1 = new FrmExercicio2(); // crio o objeto do novo formulario
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio3>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio3"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                FrmExercicio3 obj1 = new FrmExercicio3(); // crio o objeto do novo formulario
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio4>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio4"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                FrmExercicio4 obj1 = new FrmExercicio4(); // crio o objeto do novo formulario
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }
    }
}
